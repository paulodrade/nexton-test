import { Component, inject, ViewChild, ElementRef } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { MenuListModule } from '@nexton-test/ui/components';

import { SchemaService } from '@nexton-test/core/services';
import { WizardStep1Component } from './step-1/wizard-step-1.component';
import { WizardStep2Component } from './step-2/wizard-step-2.component';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Schema } from '@nexton-test/core/interfaces';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss'],
  imports: [
    MenuListModule,
    WizardStep1Component,
    WizardStep2Component,
    ReactiveFormsModule,
    AsyncPipe,
  ],
})
export class WizardComponent {
  @ViewChild('sections') sections!: ElementRef<HTMLElement>;
  currentStep = 'schemas';

  schemaService = inject(SchemaService);
  schemas$: Observable<Schema[]> = this.schemaService.getSchemas();
  currentSchema: Schema | null = null;

  schemaInput = new FormControl('');
  detailsInput = new FormControl('');
  wizardForm = new FormGroup({
    schema: this.schemaInput,
    details: this.detailsInput,
  });

  onSubmit() {
    console.log('Submitted wizard form:', this.wizardForm.value);
  }

  onSchemaSelected(schema: Schema) {
    console.log('Schema selected:', schema);
    this.currentSchema = schema;
    // Scroll usando ViewChild
    setTimeout(() => {
      this.sections?.nativeElement?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    });
  }
}
