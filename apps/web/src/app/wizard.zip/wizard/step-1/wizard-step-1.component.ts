/* Angular core imports */
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

/* Third-party and project imports */
import { Schema } from '@nexton-test/core/interfaces';
import type { IconName } from '@nexton-test/icons';
import {
  CardModule,
  RadioGroupModule,
  ButtonModule,
} from '@nexton-test/ui/components';

@Component({
  selector: 'app-wizard-step-1',
  imports: [
    CardModule,
    RadioGroupModule,
    ButtonModule,
    ReactiveFormsModule,
    RouterModule,
  ],
  templateUrl: './wizard-step-1.component.html',
  styleUrl: './wizard-step-1.component.scss',
})
export class WizardStep1Component {
  // ===========================
  // Private fields
  // ===========================
  private _schemas: Schema[] | null = [];

  // ===========================
  // Public fields
  // ===========================
  options: { label: string; value: string; icon?: IconName }[] = [];

  // ===========================
  // Inputs
  // ===========================
  @Input() schemaInput!: FormControl<string | null>;

  @Input()
  set schemas(value: Schema[] | null) {
    this._schemas = value;
    this.options =
      this._schemas?.map((schema: Schema) => ({
        label: schema.title,
        value: schema.id,
        icon: schema.icon as IconName,
      })) || [];
  }
  get schemas(): Schema[] | null {
    return this._schemas;
  }

  // ===========================
  // Outputs
  // ===========================
  @Output() onSchemaSelected = new EventEmitter<Schema>();

  // ===========================
  // Public methods
  // ===========================
  onSelectSchema(): void {
    const currentSchemaId = this.schemaInput.value;
    const currentSchema = this.schemas?.find(
      (schema) => schema.id === currentSchemaId
    );
    if (this.schemaInput.value) {
      this.onSchemaSelected.emit(currentSchema);
    }
  }
}
