import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardStep1 } from './wizard-step-1.component';

describe('WizardStep1', () => {
  let component: WizardStep1;
  let fixture: ComponentFixture<WizardStep1>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WizardStep1],
    }).compileComponents();

    fixture = TestBed.createComponent(WizardStep1);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
