import { Component, Input } from '@angular/core';
import {
  CardModule,
  ButtonModule,
  FormUI,
  MenuListModule,
} from '@nexton-test/ui/components';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Schema, Section } from '@nexton-test/core/interfaces';
import { FormGroup } from '@angular/forms';
import { normalizeName } from '@nexton-test/core/utils';

@Component({
  selector: 'app-wizard-step-2',
  standalone: true,
  imports: [
    CardModule,
    ButtonModule,
    ReactiveFormsModule,
    FormUI,
    MenuListModule,
  ],
  templateUrl: './wizard-step-2.component.html',
  styleUrl: './wizard-step-2.component.scss',
})
export class WizardStep2Component {
  @Input() detailsInput!: FormControl<string | null>;
  @Input() formGroup!: FormGroup;
  private _schema: Schema | null = null;

  @Input()
  set schema(value: Schema | null) {
    this._schema = value;
    // Não definir activeSection automaticamente; vamos renderizar todas as sections.
    this.attachFieldsToFormGroup();
  }
  get schema(): Schema | null {
    return this._schema;
  }

  get pages(): Section[] {
    return this.schema?.sections ?? [];
  }

  // Adiciona dinamicamente FormControls ao formGroup para cada field
  private attachFieldsToFormGroup() {
    if (!this.formGroup || !this.schema) return;
    for (const section of this.schema.sections ?? []) {
      for (const field of section.fields ?? []) {
        const name =
          field.name ||
          (field.label ? normalizeName(field.label) : undefined) ||
          '';
        if (!this.formGroup.contains(name)) {
          this.formGroup.addControl(name, new FormControl(''));
        }
      }
    }
  }

  activeSection: Section | null = null;

  scrollToSection(section: Section): void {
    this.activeSection = section;
    // Implement actual scroll logic as needed
    // Example: document.getElementById(section.id)?.scrollIntoView({ behavior: 'smooth' });
  }
}
