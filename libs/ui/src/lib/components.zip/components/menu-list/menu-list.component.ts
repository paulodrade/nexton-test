import { Component } from '@angular/core';

@Component({
  selector: 'nex-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrl: './menu-list.component.scss',
})
export class MenuListUI {}
