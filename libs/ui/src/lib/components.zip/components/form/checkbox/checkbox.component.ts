import { Component, Input } from '@angular/core';
import { InputBase } from '../input-base';

/**
 * NexUI checkbox component.
 * Angular form checkbox component that extends InputBase.
 *
 * @example
 * <nex-checkbox
 *   [checked]="true"
 *   [label]="''"
 *   [placeholder]="''"
 *   [readonly]="false"
 *   [value]="null"
 *   [disabled]="false"
 * ></nex-checkbox>
 *
 * @selector nex-checkbox
 * @extends InputBase
 */
@Component({
  selector: 'nex-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrl: './checkbox.component.scss',
})
export class CheckboxUI extends InputBase {
  /**
   * Whether the checkbox is checked.
   * @Input
   */
  @Input() checked = false;
}
