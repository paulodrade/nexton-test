import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckboxUI } from './checkbox.component';

describe('CheckboxUI', () => {
  let component: CheckboxUI;
  let fixture: ComponentFixture<CheckboxUI>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckboxUI],
    }).compileComponents();

    fixture = TestBed.createComponent(CheckboxUI);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
