import { Component, Input } from '@angular/core';
import { InputBase } from '../input-base';
import { LabelModule } from '../label';

@Component({
  selector: 'nex-input',
  templateUrl: './input.component.html',
  styleUrl: './input.component.scss',
  imports: [LabelModule],
})
export class InputUI extends InputBase {
  /**
   * Input type (text, password, email, tel).
   * @Input
   */
  @Input() type: 'text' | 'number' | 'password' | 'email' | 'tel' = 'text';
}
