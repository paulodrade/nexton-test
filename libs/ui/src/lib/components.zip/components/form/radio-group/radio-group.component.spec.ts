import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RadioGroupUI } from './radio-group.component';

describe('RadioGroupUI', () => {
  let component: RadioGroupUI;
  let fixture: ComponentFixture<RadioGroupUI>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RadioGroupUI],
    }).compileComponents();

    fixture = TestBed.createComponent(RadioGroupUI);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
