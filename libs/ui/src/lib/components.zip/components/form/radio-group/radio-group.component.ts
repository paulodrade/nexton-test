import {
  Component,
  Input,
  Output,
  EventEmitter,
  forwardRef,
} from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  ReactiveFormsModule,
} from '@angular/forms';
import { InputBase } from '../input-base';
import { IconName, IconUI } from '@nexton-test/icons';
import { LabelUI } from '../label/label.component';

/**
 * NexUI radio group component.
 * Angular radio group component that extends InputBase.
 * Propagates 'disabled' and 'name' inputs to all child radios for accessibility.
 *
 * @example
 * <nex-radio-group
 *   [options]="[{ value: 'a', label: 'A' }, { value: 'b', label: 'B' }]"
 *   [label]="''"
 *   [placeholder]="''"
 *   [readonly]="false"
 *   [value]="null"
 *   [disabled]="false"
 *   (valueChange)="onChange($event)"
 * ></nex-radio-group>
 *
 * @selector nex-radio-group
 * @extends InputBase
 */
@Component({
  selector: 'nex-radio-group',
  templateUrl: './radio-group.component.html',
  styleUrl: './radio-group.component.scss',
  imports: [IconUI, ReactiveFormsModule, LabelUI],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => RadioGroupUI),
      multi: true,
    },
  ],
})
export class RadioGroupUI extends InputBase implements ControlValueAccessor {
  /**
   * Array of radio options.
   * Each option should have a value and a label.
   */
  @Input() options: { value: string; label: string; icon?: IconName }[] = [];

  /**
   * Emits when the selected value changes.
   */
  @Output() valueChange = new EventEmitter<string>();

  // ControlValueAccessor implementation
  onChange!: (val: any) => void;
  onTouched!: () => void;

  /**
   * Handles radio selection.
   * @param val Selected value.
   */
  onRadioSelect(val: string) {
    if (!this.disabled) {
      this.value = val;
      this.onChange(val);
      this.onTouched();
      this.valueChange.emit(val);
    }
  }

  writeValue(value: any): void {
    this.value = value;
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }
}
