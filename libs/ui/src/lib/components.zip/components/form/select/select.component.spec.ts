import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SelectUI } from './select.component';

beforeAll(() => {
  // Mock global fetch for SVG/icon loading
  global.fetch = jest.fn(() =>
    Promise.resolve({
      text: () => Promise.resolve('<svg></svg>'),
    })
  ) as jest.Mock;
});

afterAll(() => {
  // Clean up mock
  // @ts-expect-error: Node.js does not have fetch, this disables the mock after tests
  global.fetch = undefined;
});

describe('SelectUI', () => {
  let component: SelectUI;
  let fixture: ComponentFixture<SelectUI>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SelectUI],
    }).compileComponents();

    fixture = TestBed.createComponent(SelectUI);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display options correctly', () => {
    component.options = [
      { label: 'Option 1', value: '1' },
      { label: 'Option 2', value: '2' },
    ];
    fixture.detectChanges();
    expect(component.options.length).toBe(2);
    expect(component.options[0].label).toBe('Option 1');
  });

  it('should accept placeholder', () => {
    (component as any).placeholder = 'Select...';
    fixture.detectChanges();
    expect((component as any).placeholder).toBe('Select...');
  });

  it('should accept selected value', () => {
    component.value = '2';
    fixture.detectChanges();
    expect(component.value).toBe('2');
  });

  it('should disable the select', () => {
    component.disabled = true;
    fixture.detectChanges();
    expect(component.disabled).toBe(true);
  });
});
