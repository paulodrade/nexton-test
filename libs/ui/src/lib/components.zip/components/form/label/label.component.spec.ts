import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LabelUI } from './label.component';

describe('LabelUI', () => {
  let component: LabelUI;
  let fixture: ComponentFixture<LabelUI>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LabelUI],
    }).compileComponents();

    fixture = TestBed.createComponent(LabelUI);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
