import { Input, Directive } from '@angular/core';

@Directive()
export abstract class InputBase {
  @Input() value: any;
  @Input() label = '';
  @Input() placeholder = '';
  @Input() readonly = false;
  @Input() required = false;
  @Input() name: string | undefined;

  _disabled = false;

  @Input()
  set disabled(value: boolean) {
    if (typeof value !== 'boolean') {
      return;
    }
    this._disabled = value;
  }

  get disabled(): boolean {
    return this._disabled;
  }
}
