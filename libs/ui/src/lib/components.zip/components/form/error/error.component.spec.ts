import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ErrorUI } from './error.component';

describe('ErrorUI', () => {
  let component: ErrorUI;
  let fixture: ComponentFixture<ErrorUI>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrorUI],
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorUI);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
