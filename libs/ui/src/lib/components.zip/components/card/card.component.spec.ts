import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CardComponent } from './card.component';
import { Component } from '@angular/core';

@Component({
  template: `
    <nex-card header="Header" footer="Footer">
      <div>Content</div>
    </nex-card>
  `,
  standalone: true,
  imports: [CardComponent],
})
class TestHostComponent {}

describe('CardComponent', () => {
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestHostComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TestHostComponent);
    fixture.detectChanges();
  });

  it('deve renderizar header, content e footer', () => {
    const card: HTMLElement = fixture.nativeElement.querySelector('.nex-card');
    expect(card.querySelector('.nex-card-header')?.textContent).toContain(
      'Header'
    );
    expect(card.querySelector('.nex-card-content')?.textContent).toContain(
      'Content'
    );
    expect(card.querySelector('.nex-card-footer')?.textContent).toContain(
      'Footer'
    );
  });
});
