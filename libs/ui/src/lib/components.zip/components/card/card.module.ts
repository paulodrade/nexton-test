import { NgModule } from '@angular/core';
import { CardUI } from './card.component';

@NgModule({
  imports: [CardUI],
  exports: [CardUI],
})
export class CardModule {}
